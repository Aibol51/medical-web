import{r as s}from"./request.BIpDWIEA.js";function t(t){return s.post("/mms-api/service/list",t,{noAuth:!0})}function r(t){return s.post("/mms-api/service",t,{noAuth:!0})}export{r as g,t as s};
