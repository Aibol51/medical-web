import{r as t}from"./request.BIpDWIEA.js";function s(s){return t.post("/mms-api/medicine/list",s,{noAuth:!0})}function i(s){return t.post("/mms-api/medicine",s,{noAuth:!0})}export{i as g,s as m};
