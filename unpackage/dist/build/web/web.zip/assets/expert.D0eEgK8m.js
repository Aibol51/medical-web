import{r as t}from"./request.BIpDWIEA.js";function r(r){return t.post("/mms-api/expert/list",r,{noAuth:!0})}function s(r){return t.post("/mms-api/expert",r,{noAuth:!0})}export{r as e,s as g};
